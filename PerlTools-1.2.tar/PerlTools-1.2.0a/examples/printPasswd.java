/***
 * printPasswd.java,v 1.3 1998/03/10 08:02:45 dfs Exp
 *
 * This is an example program based on a short example from the Camel book.
 * It demonstrates splits by reading the /etc/passwd file (assuming you're
 * on a Unix system) and printing out the formatted entries.
 *
 * Copyright 1997 Original Reusable Objects, Inc.  All rights reserved.
 ***/


import java.io.*;
import java.util.*;

import com.oroinc.text.perl.*;


public final class printPasswd {
  public static final String[] fieldNames = {
    "Login: ", "Encrypted password: ", "UID: ", "GID: ", "Name: ",
    "Home: ", "Shell: "
  };

  public static final void main(String args[]) {
    BufferedReader input = null;
    int field, record;
    String line;
    Enumeration fields;
    Perl5Util perl;

    try {
      input = new BufferedReader(new FileReader("/etc/passwd"));
    } catch(IOException e) {
      System.err.println("Could not open /etc/passwd.");
      e.printStackTrace();
      System.exit(1);
    }

    perl = new Perl5Util();
    record = 0;

    try {
      while((line = input.readLine()) != null) {
	fields = perl.split("/:/", line).elements();
	field = 0;

	System.out.println("Record " + record++); 

	while(fields.hasMoreElements() && field < fieldNames.length)
	  System.out.println(fieldNames[field++] + 
			     (String)fields.nextElement());

	System.out.print("\n\n");
      }
    } catch(IOException e) {
      System.err.println("Error reading /etc/passwd.");
      e.printStackTrace();
      System.exit(1);
    } finally {
      try {
	input.close();
      } catch(IOException e) {
	System.err.println("Could not close /etc/passwd.");
	e.printStackTrace();
	System.exit(1);
      }
    }

  }

}
