/***
 * jdfix.java,v 1.3 1998/03/10 08:02:45 dfs Exp
 *
 * This is an example program demonstrating how to use the PerlTools
 * match and substitute methods.
 *
 * Copyright 1997 Original Reusable Objects, Inc.  All rights reserved.
 ***/


import java.io.*;

import com.oroinc.text.perl.*;


public final class jdfix {

  /***
   * This program performs the exact same function as this Perl script.
   * Notice that the Java program is only so much longer because of all
   * of the I/O exception handling and InputStream creation.  The core
   * while loop is EXACTLY the same length as the while loop in the Perl
   * script.  This program uses DataInputStream, readLine(), and 
   * PrintStream for JDK 1.0.2 compatibility.
   * <p>
   * This is a simple program that takes a javadoc generated HTML file as
   * input and produces as output the same HTML file, except with a white
   * background color for the body.
   * <p>
   * <pre>
   * #!/usr/bin/perl
   *
   * $#ARGV >= 1 || die "Usage: jdfix input output\n";
   *
   * open(INPUT, $ARGV[0]) || warn "Couldn't open $ARGV[0]\n";
   * open(OUTPUT, ">$ARGV[1]") || warn "Couldn't open $ARGV[1]\n";
   *
   * while(<INPUT>){
   *     s/<body>/<body bgcolor="#ffffff">/;
   *     print OUTPUT;
   * }
   * 
   * close(INPUT);
   * close(OUTPUT);
   * </pre>
   ***/

  public static final void main(String args[]) {
    String line;
    BufferedReader input = null;
    PrintWriter output    = null;
    Perl5Util perl;

    if(args.length < 2) {
      System.err.println("Usage: jdfix input output");
      System.exit(1);
    }

    try {
      input = 
	new BufferedReader(new FileReader(args[0]));
    } catch(IOException e) {
      System.err.println("Error opening input file: " + args[0]);
      e.printStackTrace();
      System.exit(1);
    }

    try {
      output =
	new PrintWriter(new FileWriter(args[1]));
    } catch(IOException e) {
      System.err.println("Error opening output file: " + args[1]);
      e.printStackTrace();
      System.exit(1);
    } 

    perl = new Perl5Util();

    try {
      while((line = input.readLine()) != null) {
	line = perl.substitute("s/<body>/<body bgcolor=\"#ffffff\">/", line);
	output.println(line);
      }
    } catch(IOException e) {
      System.err.println("Error reading from input: " + args[1]);
      e.printStackTrace();
      System.exit(1);
    } finally {
      try {
	input.close();
	output.close();
      } catch(IOException e) {
	System.err.println("Error closing files.");
	e.printStackTrace();
	System.exit(1);
      }
    }
  }

}
