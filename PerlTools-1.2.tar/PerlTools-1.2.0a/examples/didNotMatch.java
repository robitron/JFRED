/***
 * didNotMatch.java,v 1.1 1997/07/06 02:55:55 dfs Exp
 *
 * This is a trivial example program demonstrating the preMatch()
 * and postMatch() methods of Perl5Util.
 *
 * Copyright 1997 Original Reusable Objects, Inc.  All rights reserved.
 ***/

import com.oroinc.text.regex.*;
import com.oroinc.text.perl.*;

public final class didNotMatch {

  /***
   * This program takes a Perl5 pattern and an input string as arguments.
   * It prints the parts of the input surrounding the first occurrence
   * of the pattern in the input.
   ***/

  public static final void main(String args[]) {
    String pattern, input;
    Perl5Util perl;

    if(args.length < 2) {
      System.err.println("Usage: didNotMatch pattern input");
      System.exit(1);
    }

    pattern = args[0];
    input   = args[1];
    perl    = new Perl5Util();

    // Use a try block because we have no idea if the user will enter a valid
    // pattern.
    try {
      if(perl.match(pattern, input)) {
	System.out.println("Pre : " + perl.preMatch());
	System.out.println("Post: " + perl.postMatch());
      } else
	System.err.println("There was no match.");
    } catch(MalformedPerl5PatternException e) {
      System.err.println("You entered an invalid pattern.");
      System.err.println("Error: " + e.getMessage());
      System.exit(1);
    }

  }

}
