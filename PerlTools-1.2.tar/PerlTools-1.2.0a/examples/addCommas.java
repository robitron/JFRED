/***
 * addCommas.java,v 1.1 1997/07/03 02:03:38 dfs Exp
 *
 * This is an example program based on a short example from the Camel book.
 * It demonstrates substitutions by adding commas to a the string
 * representation of an integer.
 *
 * Copyright 1997 Original Reusable Objects, Inc.  All rights reserved.
 ***/

import com.oroinc.text.perl.*;

public final class addCommas {

  /***
   * This program takes a string as an argument and adds commas to all the
   * integers in the string exceeding 3 digits in length, placing each comma
   * three digits apart.
   ***/

  public static final void main(String args[]) {
    String number;
    Perl5Util perl;

    if(args.length < 1) {
      System.err.println("Usage: addCommas integer");
      System.exit(1);
    }

    number = args[0];
    perl = new Perl5Util();

    while(perl.match("/[+-]?\\d*\\d{4}/", number))
      number = perl.substitute("s/([+-]?\\d*\\d)(\\d{3})/$1,$2/", number);

    System.out.println(number);
  }

}
