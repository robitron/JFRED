/***
 * strings.java,v 1.3 1997/07/06 01:34:00 dfs Exp
 *
 * This is an example program emulating the Unix strings command invoked
 * with the -a flag.  It extracts all printable character sequences of
 * at least 4 characters from a file.  Notice how the core work is done
 * in a two line loop.  The excess code is exception handling.
 *
 * Copyright 1997 Original Reusable Objects, Inc.  All rights reserved.
 ***/

import java.io.*;

import com.oroinc.text.regex.*;
import com.oroinc.text.perl.*;

public final class strings {

  public static final void main(String args[]) {
    InputStream input = null;
    Perl5Util perl;
    Perl5StreamInput stream;

    if(args.length < 1) {
      System.err.println("Usage: strings filename");
      System.exit(1);
    }
      
    try {
      input = new BufferedInputStream(new FileInputStream(args[0]));
    } catch(IOException e) {
      System.err.println("Could not open input file: " + args[0]);
      e.printStackTrace();
      System.exit(1);
    }

    perl = new Perl5Util();
    stream = new Perl5StreamInput(input);

    try {

      while(perl.match("/[\\x20-\\x7e]{4,}/", stream))
	System.out.println(perl.group(0));

    } catch(IOException e) {
      System.err.println("Error reading input: " + args[0]);
      e.printStackTrace();
      System.exit(1);
    } finally {
      try {
	input.close();
      } catch(IOException e) {
	System.err.println("Could not close file.");
	e.printStackTrace();
	System.exit(1);
      }
    }

  }

}
